To use the aplication, run the script "run.m" in matlab.
By default, the script automaticly runs all the possible options. To manually choose the parameters, comment the part of the script that follows the comment "% automated param choice", and uncomment this line : "%ocr_fun(data, training_set);"
One can also run the application, by directly calling the mpaper function "mpaper.m script", and manually write the characters to classify.
